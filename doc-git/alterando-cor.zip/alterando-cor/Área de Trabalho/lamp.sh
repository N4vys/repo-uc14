#!/bin/bash
sudo /opt/lampp/manager-linux-x64.run
