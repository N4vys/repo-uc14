let idade = parseInt(prompt("Sua idade:"))

if (idade >= 18) {
    document.write("Você é maior de idade")
} else {
    document.write("Você é menor de idade")
}