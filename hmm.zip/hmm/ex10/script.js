let diastrabalhados = parseInt(prompt("Dias de trabalho:"))
let valordiaria = parseInt(prompt("Valor da diaria:"))

let salario = diastrabalhados * valordiaria

document.write(salario)