let km = parseInt(prompt("Digite os quilometros"))
let milhas = parseFloat(0.621371)

let converter = (milhas * km).toFixed(2)

document.write(parseFloat(converter))
