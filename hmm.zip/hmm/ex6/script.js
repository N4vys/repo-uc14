let numero = parseInt(prompt("Insira o numero aqui:"));

if (numero % 2 === 0){
    document.write("O numero é par");
} else {
    document.write("O numero não é par");
}