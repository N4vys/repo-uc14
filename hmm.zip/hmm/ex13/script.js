let fahrenheit = parseInt(prompt("Insira aqui a temperatura em Celsius"))
let celsius = (fahrenheit - 32) * 5 / 9

document.write(celsius)