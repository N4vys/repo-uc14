 let valorconta = parseInt(prompt("Valor da conta:"))
 let clientes = parseInt(prompt("Numero de clientes:"))

 let pagamento = valorconta / clientes

 document.write(parseFloat(pagamento))