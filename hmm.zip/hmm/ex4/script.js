let nota1 = parseFloat(prompt("Insira sua nota:"))
let nota2 = parseInt(prompt("Insira sua segunda nota"))

let soma = nota1 + nota2
let media = soma / 2

document.write(parseFloat(media))