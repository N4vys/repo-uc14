let celsius = parseInt(prompt("Insira aqui a temperatura em Celsius"))
let fahrenheit = celsius * 1.8 + 32

document.write(fahrenheit)