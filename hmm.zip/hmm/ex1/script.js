let numero5 = parseInt(prompt("insira o numero 1 aqui:"))
let numero4 = parseInt(prompt("insira o numero 2 aqui:"))
let add = numero5 + numero4

document.write(add)