let quilometros = parseInt(prompt("Distancia percorrida"))
let consumo = parseInt(prompt("Consumo do combustivel"))

let consumoMedio = quilometros / consumo

document.write("O consumo médio é:" + " " + consumoMedio + " km/L ")