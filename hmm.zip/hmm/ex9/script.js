let raio = parseInt(prompt("Insira o raio do circulo"))

const PI = Math.PI
let perimetro = 2* PI *raio

document.write(perimetro)