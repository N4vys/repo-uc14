let base = parseInt(prompt("Insira a base"))
let altura = parseInt(prompt("Insira a altura"))

let area = base * altura

document.write(area)