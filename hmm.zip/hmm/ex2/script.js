let idade = parseInt(prompt("insira a idade aqui"))
let calculo = idade * 365

document.write(calculo)