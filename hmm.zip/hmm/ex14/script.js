let minutos = parseInt(prompt("Insira os minutos:"))
let hrs = (minutos / 60).toFixed(2)

document.write(hrs)