let deposito = parseInt(prompt("Fale o deposito:"))
let juros = parseInt(prompt("Fale os juros:"))

let rendimento = juros * deposito / 100

let valortotal = rendimento + deposito

document.write(valortotal)



